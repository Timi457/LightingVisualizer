﻿using System.Collections;
using UnityEngine;

public class LightIntensity : MonoBehaviour {

    public Light spot;

	// Update is called once per frame
	void Update () {
        if(Input.GetKey("space")){
            spot.enabled = false;
        } else{
            spot.enabled = true;
        }
		
	}
}
