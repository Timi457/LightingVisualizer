﻿using UnityEngine;
using System.Collections;

public class SpecialLight : MonoBehaviour
{
    private Light myLight;


    void Start()
    {
        myLight = GetComponent<Light>();
    }


    void Update()
    {
        if (Input.GetKeyUp(KeyCode.RightShift))
        {
            myLight.enabled = !myLight.enabled;
        }
    }
}