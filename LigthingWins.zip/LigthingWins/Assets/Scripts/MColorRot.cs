﻿using UnityEngine;

public class MColorRot : MonoBehaviour
{
    // Interpolate light color between two colors back and forth
    float duration = 0.5f;
    Color colorC = Color.cyan;
    Color colorM = Color.magenta;
    Color colorB = Color.blue;
    Color colorR = Color.red;
    Color colorY = Color.yellow;
    Color colorG = Color.green;
    Color colorBl = Color.black;
    Color colorW = Color.white;

    Light lt;

    void Start()
    {
        lt = GetComponent<Light>();
    }

    void Update()
    {
        if (Input.GetKeyUp(KeyCode.C))
        {
            // set light color
            /* float t = Mathf.PingPong(Time.time, duration) / duration;
             lt.color = Color.Lerp(color0, color1, t);*/
            lt.color = colorC;
        }

        if (Input.GetKeyUp(KeyCode.M))
        {
            lt.color = colorM;
        }

        if (Input.GetKeyUp(KeyCode.B))
        {
            lt.color = colorB;
        }

        if (Input.GetKeyUp(KeyCode.R))
        {
            lt.color = colorR;
        }

        if (Input.GetKeyUp(KeyCode.Tab))
        {
            lt.color = colorBl;
        }

        if (Input.GetKeyUp(KeyCode.Y))
        {
            lt.color = colorY;
        }

        if (Input.GetKeyUp(KeyCode.G))
        {
            lt.color = colorG;
        }

        if (Input.GetKeyUp(KeyCode.W))
        {
            lt.color = colorW;
        }
    }
}